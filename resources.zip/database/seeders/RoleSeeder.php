<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class RoleSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('roles')->insert([
            'role_name' => 'Super Admin',
            'manage_user' => 'on',
            'manage_item' => 'on',
            'manage_location' => 'on',
            'set_item_price' => 'on',
            'manage_delete_user' => 'on',
            'manage_delete_item' => 'on',
            'manage_delete_sales' => 'on',
            'manage_delete_customer' => 'on',
            'manage_delete_goodreceiving' => 'on',
            'manage_item_unit' => 'on',
            'manage_category' => 'on',
            'manage_shelf' => 'on',
            'manage_good_receiving' => 'on',
            'manage_customer' => 'on',
            'manage_customer_history' => 'on',
            'manage_item_transfer' => 'on',
            'manage_sales' => 'on',
            'manage_disposal' => 'on',
            'manage_activity_log' => 'on',
            'approval' => 'on',
            'manage_stock_reports' => 'on',
            'manage_shopStock_reports' => 'on',
            'created_at' => now(),
            'updated_at' => now(),
        ]);
    }
}
