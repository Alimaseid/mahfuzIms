<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('items', function (Blueprint $table) {
            $table->id();
            $table->string('item_name');
            $table->string('category');
            $table->string('quantity')->nullable();
            $table->string('product_code')->nullable();
            $table->string('unit')->nullable();
            $table->string('weight')->nullable();
            $table->string('dimension')->nullable();
            $table->string('manufacturer')->nullable();
            $table->string('cost_price')->nullable();
            $table->string('selling_price1')->nullable();
            $table->string('selling_price2')->nullable();
            $table->string('selling_price3')->nullable();
            $table->string('part_number')->nullable();
            $table->string('universal_product_code')->nullable();
            $table->string('image')->nullable();;
            $table->string('supplier_name')->nullable();
            $table->string('serial_number')->nullable();
            $table->string('bar_code')->nullable();
            $table->string('status')->nullable();
            $table->text('description')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('items');
    }
};
