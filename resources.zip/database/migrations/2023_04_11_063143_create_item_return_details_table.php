<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('item_return_details', function (Blueprint $table) {
            $table->id();
            $table->foreignId('return_id');
            $table->foreignId('item_id');
            $table->string('quantity');
            $table->string('price');
            $table->string('return_to')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('item_return_details');
    }
};
