<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('item_on_shops', function (Blueprint $table) {
            $table->id();
            $table->foreignId('item_id');
            $table->string('item_name');
            $table->foreignId('location_id');
            $table->string('location_type');
            $table->string('location_name');
            $table->string('qauntity');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('item_on_shops');
    }
};
