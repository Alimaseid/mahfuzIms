<?php

namespace App\Http\Controllers;

use App\Models\Item;
use App\Models\Owner;
use App\Models\Vendor;
use App\Models\Category;
use Illuminate\Http\Request;
use App\Models\PurchaseOrder;
use App\Models\BusinessLocation;
use App\Models\PurchaseOrderDetail;
use App\Http\Requests\StorePurchaseOrderRequest;
use App\Http\Requests\UpdatePurchaseOrderRequest;
use App\Models\BankList;
use App\Models\ItemOwner;
use App\Models\PurchaseLedger;
use App\Models\PurchsePayment;
use Illuminate\Support\Str;


class PurchaseOrderController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $purchaseOrders = PurchaseOrder::orderBy('id', 'desc')->get();
        $vendors = Vendor::all();
        $businessLocations = BusinessLocation::where('type','Warehouse')->get();
        $owners = Owner::all();
        $items = Item::all();
        $purchaseOrderDetails = PurchaseOrderDetail::all();
        return view('pages.purchase.purchase')
        ->with('owners', $owners)
        ->with('businessLocations', $businessLocations)
        ->with('items', $items)
        ->with('vendors', $vendors)
        ->with('purchaseOrderDetails', $purchaseOrderDetails)
        ->with('purchaseOrders', $purchaseOrders);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function addPurchaseOrder(Request $request)
    {
        PurchaseOrder::create([
            'vender' => $request->vendor,
            'reference_number'  =>$request->refrence_no,
            'shipment_reference'    =>$request->shipment_reference,
            'business_location' =>$request->business_location,
            'owner' =>$request->owner,
            'payment_terms' =>$request->payment_type,
            'check_no'  =>$request->check_no,
            'account_number'    =>$request->account_number,
            'expected_delivery_date'    =>$request->expected_delivery_date,
            // 'total_payment' =>0,
        ]);

        $pOrder = PurchaseOrder::select('id')->latest()->first();
        $grand_total = 0;
        for($i=0; $i < sizeof($request->addmore); $i++){
            $item = Item::where('id',$request->addmore[$i]['item_id'])->first();
            if($item != null){
                $item_to_owner = ItemOwner::where('item_id',$item->id)->where('owner_id',$request->owner)->where('location_id',$request->business_location)->first();
                if($item != null){
                    $total = $request->addmore[$i]['u_price'] * $request->addmore[$i]['quantity'];
                    $subtotal = ($total * $request->vat_include /100) + $request->addmore[$i]['u_price'] * $request->addmore[$i]['quantity'];
                    $grand_total = $grand_total + $subtotal;
                    PurchaseOrderDetail::create([
                        'item_id' => $item->id,
                        'item_name'=> $item->item_name.' # '.$item->product_code,
                        'qunatity'=> $request->addmore[$i]['quantity'],
                        'amount' => $request->addmore[$i]['u_price'] * $request->addmore[$i]['quantity'],
                        'tax'=> $request->vat_include,
                        'total' => ($request->addmore[$i]['u_price'] * $request->addmore[$i]['quantity'] * $request->vat_include /100) + $request->addmore[$i]['u_price'] * $request->addmore[$i]['quantity'],
                        'purchase_order_id' => $pOrder->id,
                    ]);
                    Item::where('id',$item->id)->update(['quantity' => $item->quantity + $request->addmore[$i]['quantity']]);
                    if($item_to_owner != null){
                        ItemOwner::where('id', $item_to_owner->id)->update(['quantity' => $item_to_owner->quantity + $request->addmore[$i]['quantity']]);
                    }else{
                        ItemOwner::create([
                           'owner_id' =>$request->owner,
                           'item_id'=>$item->id,
                           'item_name'=>$item->item_name,
                           'location_id'=> $request->business_location,
                           'quantity'=>$request->addmore[$i]['quantity'],
                        ]);
                    }

                }else{
                      return back()->with('error',Str::of($request->addmore[$i]['search_item'])->after(',').'is Not Found On Item List.');
                }
            }else{
                $pOrder->delete();
                return back()->with('error',Str::of($request->addmore[$i]['search_item'])->after(',').' Item Not Found On Item List. Please Register on Item List First.');
            }

        }
        // PurchaseOrder::where('id', $pOrder->id)->update(['total_payment' => $grand_total,'status' => 'NotPaid']);
        // $ledger = PurchaseLedger::where('to',$request->vendor)->latest()->first();
        // if(!empty($ledger)){
        //     PurchaseLedger::create([
        //         'by' =>$request->owner,
        //         'to' => $request->vendor,
        //         'purchase_order_id'=>$pOrder->id,
        //         'debit' => $grand_total,
        //         'credit' => 0,
        //         'balance' => $ledger->balance + $grand_total,
        //     ]);

        // }else{
        //     PurchaseLedger::create([
        //         'by' =>$request->owner,
        //         'to' => $request->vendor,
        //         'purchase_order_id'=>$pOrder->id,
        //         'debit' => $grand_total,
        //         'credit' => 0,
        //         'balance' =>$grand_total,
        //     ]);
        // }


        return back()->with('success','Register Order Successfully.');
    }


//Edit Purchase Order
    public function editPurchaseOrder(Request $request ,$id){
        PurchaseOrder::where('id',$id)->update([
            'vender' => $request->vendor,
            'shipment_reference'    =>$request->shipment_reference,
            'business_location' =>$request->business_location,
            'owner' =>$request->owner,
            'payment_terms' =>$request->payment_type,
            'expected_delivery_date'    =>$request->expected_delivery_date,
            // 'total_payment' =>0,
        ]);
        $pOrder = PurchaseOrder::where('id',$id)->first();

        $grand_total = 0;
        for($i=0; $i < sizeof($request->addmore); $i++){
            $item = Item::where('id',$request->addmore[$i]['item_id'])->first();
            if($item != null){
                $item_to_owner = ItemOwner::where('item_id',$item->id)->where('owner_id',$request->owner)->where('location_id',$request->business_location)->first();
                if($item != null){
                    $total = $request->addmore[$i]['u_price'] * $request->addmore[$i]['quantity'];
                    $subtotal = ($total * $request->vat_include /100) + $request->addmore[$i]['u_price'] * $request->addmore[$i]['quantity'];
                    $grand_total = $grand_total + $subtotal;
                    $itemList = PurchaseOrderDetail::where('purchase_order_id',$pOrder->id)->where('item_id',$item->id)->first();
                    $itemDif = $request->addmore[$i]['quantity'] - $itemList->qunatity ;

                    Item::where('id',$item->id)->update(['quantity' => $item->quantity - (-$itemDif)]);

                    if($item_to_owner != null){
                      ItemOwner::where('id', $item_to_owner->id)
                        ->where('item_id', $item->id)
                        ->update(['quantity' => $item_to_owner->quantity - (-$itemDif)]);
                    }else{
                        ItemOwner::create([
                           'owner_id' =>$request->owner,
                           'item_id'=>$item->id,
                           'item_name'=>$item->item_name,
                           'location_id'=> $request->business_location,
                           'quantity'=>$request->addmore[$i]['quantity'],
                        ]);
                    }

                    PurchaseOrderDetail::where('purchase_order_id',$pOrder->id)->where('item_id',$item->id)->update([
                        'qunatity'=> $request->addmore[$i]['quantity'],
                        'amount' => $request->addmore[$i]['u_price'] * $request->addmore[$i]['quantity'],
                        'tax'=> $request->vat_include,
                        'total' => ($request->addmore[$i]['u_price'] * $request->addmore[$i]['quantity'] * $request->vat_include /100) + $request->addmore[$i]['u_price'] * $request->addmore[$i]['quantity'],
                    ]);


                }else{
                      return back()->with('error',Str::of($request->addmore[$i]['search_item'])->after(',').'is Not Found On Item List.');
                }
            }else{
                $pOrder->delete();
                return back()->with('error',Str::of($request->addmore[$i]['search_item'])->after(',').' Item Not Found On Item List. Please Register on Item List First.');
            }

        }

        // PurchaseOrder::where('id', $id)->update(['total_payment' => $grand_total,'status' => 'NotPaid']);
        // $ledger = PurchaseLedger::where('purchase_order_id',$id)->latest()->first();
        // $lagerDif = $grand_total - $ledger->debit;
        // if(!empty($ledger)){
        //     PurchaseLedger::where('id',$ledger->id)->update([
        //         'by' =>$request->owner,
        //         'to' => $request->vendor,
        //         'purchase_order_id'=>$id,
        //         'debit' => $grand_total,
        //         'credit' => 0,
        //         'balance' => $ledger->balance - (-$lagerDif),
        //     ]);

        //     $latesLedgers = PurchaseLedger::where('id','>',$ledger->id)->get();

        //     foreach ($latesLedgers as $latesLedger){
        //         PurchaseLedger::where('id',$latesLedger->id)->update([
        //             'balance' => $latesLedger->balance - (-$lagerDif),
        //         ]);
        //     }
        // }

        return back()->with('success','Update Order Successfully.');

    }

    public function deletePurchaseOrders($id){
        $purchase = PurchaseOrder::where('id', $id)->first();
        $orderDetail = PurchaseOrderDetail::where('purchase_order_id',$id)->get();
        foreach($orderDetail as $data){
          $item = Item::where('id',$data->item_id)->first();
          $item_owner = ItemOwner::where('owner_id',$purchase->owner)->Where('item_id',$data->item_id)->first();
          if($item_owner != null){
            ItemOwner::where('owner_id',$item_owner->owner_id)->Where('item_id',$item_owner->item_id)
            ->update(['quantity' => $item_owner->quantity - $data->qunatity ]);
            Item::where('id',$item->id)->update(['quantity' => $item->quantity - $data->qunatity ]);
          }
        }

        PurchaseOrder::where('id', $id)->delete();
        PurchaseOrderDetail::where('purchase_order_id',$id)->delete();
        // PurchaseLedger::where('purchase_order_id',$id)->delete();
        return back()->with('success','Delete Order Successfully.');
    }

    public function purchsePayments($id){
        $vender = Vendor::where('id', $id)->first();
        $owners = Owner::all();
        $purchasPayments = PurchsePayment::where('vendor_id', $id)->get();
        $banks = BankList::all();
        $ledger = PurchaseLedger::orderBy('created_at','desc')->where('to',$id)->get();
        $latestBalance = PurchaseLedger::where('to',$id)->latest()->first();

        $data = [];
        $own = [];
        $owner_balance = [];
        foreach ( $ledger as $lg){
            foreach($owners as $owner){
                if($owner->id == $lg->by){
                    $data [] = [
                        'id' =>$lg->id,
                        'date' =>$lg->created_at->toDateString(),
                        'credit' => $lg->credit,
                        'owner' => $owner->name,
                        'debit' => $lg->debit,
                        'balance' => $lg->balance,
                    ];
                    $own [] = $owner->id;
                }
            }
        }
        foreach(array_unique($own) as $owner){
           $owner_ledger = PurchaseLedger::where('to',$id)->where('by',$owner)->get();
           $ownerData = owner::where('id',$owner)->first();
           $debit = 0;
           $credit = 0;
           foreach($owner_ledger as $ob){
                $debit =  $debit + $ob->debit;
                $credit = $credit + $ob->credit;
           }
           $owner_balance [] = ['owner_id'=>$ownerData->id,'owner'=>$ownerData->name,'balance'=>$debit-$credit];
        }

        $netData = ['id'=>$vender->id,'vender'=>$vender->name,'latestBalance'=>$latestBalance->balance,'ledger'=>$data,'owner_balance'=>$owner_balance];
        return view('pages.purchase.purchasePayment')
        ->with('purchasPayments',$purchasPayments)
        ->with('banks',$banks)
        ->with('netData',$netData);
    }

    public function purchasePayment(Request $request,$owner_id,$vendor_id){
       $latestBalance = PurchaseLedger::latest()->first();
        PurchaseLedger::create([
            'by' =>$owner_id,
            'to' => $vendor_id,
            'debit' => 0,
            'credit' => $request->amount + $request->discount,
            'balance' =>$latestBalance->balance - ($request->amount + $request->discount),
        ]);
        $PL = PurchaseLedger::latest()->first();
        $photo = $request->file('docs');
        $doc_path = '';
        if($photo){
            $doc_name = $photo->getClientOriginalName();
            $doc_path = $photo->move('images/payment-docs',$doc_name);
         }

        PurchsePayment::create([
            'date' => $request->date,
            'amount'    =>$request->amount,
            'discount'  =>$request->discount,
            'refrence_no'   =>$request->refrence_no,
            'payment_type'  =>$request->payment_type,
            'BankName'  =>$request->bank,
            'Docs'  =>$doc_path,
            'Remarks'   =>$request->remark,
            'owner_id'=>$owner_id,
            'vendor_id'=>$vendor_id,
            'PL_id'=>$PL->id,
        ]);

        return back()->with('success','Transaction Done.');
    }

    public function editPurchasePayment(Request$request,$id){
        $payment =  PurchsePayment::where('id',$id)->first();
        $lg =  PurchaseLedger::where('id',$payment->PL_id)->first();
        $owner_ledger =  PurchaseLedger::where('id','>',$payment->PL_id)->get();
        $def = $payment->amount - ( $request->amount + $request->discount);

        //update after the updated lager id to latest one.
        foreach($owner_ledger as $ledger){
            PurchaseLedger::where('id',$ledger->id)->update([
                'balance' =>$ledger->balance - (-$def),
            ]);
        }
        PurchaseLedger::where('id',$payment->PL_id)->update([
            'credit' => $request->amount + $request->discount,
            'balance' =>$lg->balance - (-$def),
        ]);

        $photo = $request->file('docs');
        $doc_path = '';
        if($photo){
            $doc_name = $photo->getClientOriginalName();
            $doc_path = $photo->move('images/payment-docs',$doc_name);
         }else{
           $doc_path = $payment->Docs;
         }
        PurchsePayment::where('id',$id)->update([
            'date' => $request->date,
            'amount'    =>$request->amount,
            'discount'  =>$request->discount,
            'refrence_no'   =>$request->refrence_no,
            'payment_type'  =>$request->payment_type,
            'BankName'  =>$request->bank,
            'Docs'  =>$doc_path,
            'Remarks'   =>$request->remark,
        ]);

        return back()->with('success','Transaction Updated.');
    }

    public function deletePurchasePayment($id) {
        $payment =  PurchsePayment::where('id',$id)->first();
        $lg =  PurchaseLedger::where('id',$payment->PL_id)->first();
        $owner_ledger =  PurchaseLedger::where('id','>',$payment->PL_id)->get();

        foreach($owner_ledger as $ledger){
            PurchaseLedger::where('id',$ledger->id)->update([
                'balance' =>$ledger->balance + ($payment->amount + $payment->discount),
            ]);
        }

        $lg->delete();
        $payment->delete();

        return back()->with('success','Transaction Deleted.');

    }

    public function vendorPurchaseHistory($id){
    $purchaseOrder = PurchaseOrder::where('vender',$id)->orderBy('created_at','desc')->get();
    $vendor = Vendor::find($id);
    $data = [];
    foreach($purchaseOrder as $po){
      $pods = PurchaseOrderDetail::where('purchase_order_id',$po->id)->get();
      foreach($pods as $pod){
      $item = Item::find($pod->item_id);
          if(!empty($item)){
            $pod_data [] = [
                'order_id' => $pod->purchase_order_id,
                'item_id' => $item->id,
                'item_code' => $item->product_code,
                'quantity' => $pod->qunatity,
                'total' => $pod->amount,
                'tax' => $pod->tax,
                'grand_total' => $pod->total,
            ];
          }

      }
      $location = BusinessLocation::find($po->business_location);
      $owner = Owner::find($po->owner);
      if(!empty($item)){
        if(!empty($item)){
          $data[] =[
          'id' =>$po->id,
          'date' =>$po->created_at,
          'RF' =>$po->reference_number,
          'location'=>$location->name,
          'owner' => $owner->name,
          'payment_terms' => $po->payment_terms,
          'total_payment' => $po->total_payment,
          'Details'=>$pod_data];
        }
     }
    }
    return view('pages.purchase.vendorPurchaseHistory')
    ->with('vendor', $vendor->name)
    ->with('data', $data);
    }

}
