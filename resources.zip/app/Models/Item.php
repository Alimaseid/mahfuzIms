<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Item extends Model
{
    use HasFactory;
    protected $fillable = [
        'item_name',
        'category',
        'quantity',
        'product_code',
        'unit',
        'weight',
        'dimension',
        'manufacturer',
        'cost_price',
        'selling_price1',
        'selling_price2',
        'selling_price3',
        'part_number',
        'universal_product_code',
        'image',
        'supplier_name',
        'serial_number',
        'bar_code',
        'status',
        'description',
        'reorder',
        'shelves_id',
        'image2',

    ];
      public function shelf()
    {
        return $this->belongsTo(Shelf::class, 'shelves_id');
    }
}
