<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ShopStock extends Model
{
    use HasFactory;
     protected $fillable = ['item_name','quantity','part_number','product_code','bar_code'];

}
