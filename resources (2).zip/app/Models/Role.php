<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Role extends Model
{
    use HasFactory;

    protected $fillable = [
        'role_name',
        'manage_user',
        'manage_location',
        'manage_item',
        'set_item_price',
        'manage_delete_goodreceiving',
        'manage_item_unit',
        'manage_category',
        'manage_delete_user',
        'manage_shelf',
        'manage_customer',
        'manage_delete_item',
        'manage_good_receiving',
        'manage_customer_history',
        'manage_delete_sales',
        'manage_item_transfer',
        'manage_sales',
        'manage_delete_customer',
        'manage_disposal',
        'manage_activity_log',
        'approval',
        'manage_stock_reports',
        'manage_shopStock_reports',
    ];
}
