<?php

namespace App\Http\Controllers;

use App\Models\Role;
use App\Models\User;
use Illuminate\Http\Request;
use App\Http\Requests\StoreRoleRequest;
use App\Http\Requests\UpdateRoleRequest;

class RoleController extends Controller
{
    public function addRole(Request $request)
    {
        $role = Role::create([
            'role_name' => $request->role_name,
            'manage_user' => $request->manage_user,
            'manage_location' => $request->manage_location,
            'manage_item' => $request->manage_item,
            'manage_delete_user' => $request->manage_delete_user,
            'manage_delete_item' => $request->manage_delete_item,
            'manage_delete_customer' => $request->manage_delete_customer,
            'manage_delete_goodreceiving' => $request->manage_delete_goodreceiving,
            'manage_delete_sales' => $request->manage_delete_sales,
            'set_item_price' => $request->set_item_price,
            'manage_category' => $request->manage_category,
            'manage_shelf' => $request->manage_shelf,
            'manage_good_receiving' => $request->manage_good_receiving,
            'manage_item_transfer' => $request->manage_item_transfer,
            'manage_customer' => $request->manage_customer,
            'manage_customer_history' => $request->manage_customer_history,
            'manage_sales' => $request->manage_sales,
            'manage_disposal' => $request->manage_disposal,
            'manage_activity_log' => $request->manage_activity_log,
            'approval' => $request->approval,
            'manage_shopStock_reports' => $request->manage_shopStock_reports,
            'manage_stock_reports' => $request->manage_stock_reports
        ]);

        // ✅ Log activity
        activity()
            ->causedBy(auth()->user())
            ->performedOn($role)
            ->withProperties(['data' => $role->toArray()])
            ->log('Added a new role');

        return back()->with('success', 'New Role Added.');
    }

    public function editRole(Request $request, $id)
    {
        $role = Role::findOrFail($id);

        $role->update($request->except('_token'));

        // ✅ Log activity
        activity()
            ->causedBy(auth()->user())
            ->performedOn($role)
            ->withProperties(['data' => $role->toArray()])
            ->log('Edited a role');

        return back()->with('success', 'Role Updated.');
    }

    public function deleteRole($id)
    {
        $role = Role::findOrFail($id);

        // ✅ Log activity before delete
        activity()
            ->causedBy(auth()->user())
            ->performedOn($role)
            ->withProperties(['data' => $role->toArray()])
            ->log('Deleted a role');

        $role->delete();

        return back()->with('success', 'Role Deleted.');
    }

    public function setRole(Request $request, $id)
    {

        $user = User::findOrFail($id);
        $user->role;
        $oldRole = $user->role;
        $user->role = $request->role;
        $user->update();

        // ✅ Log activity
        activity()
            ->causedBy(auth()->user())
            ->performedOn($user)
            ->withProperties([
                'old_role' => $oldRole,
                'new_role' => $request->role
            ])
            ->log('Changed user role');

        return back()->with('success', 'Set Role Succeed.');
    }
}
