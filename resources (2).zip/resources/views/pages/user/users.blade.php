@extends('inc.frame')


@section('content')
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="card card-primary card-outline">
                        <div class="card-header">
                            <h3 class="card-title">
                                <div class="text-warning" style="float: left">Total Users : <b> {{ count($users) }}</b></div>
                            </h3>
                            <button type="button" class="btn btn-primary pull-rigth" style="float: right;"
                                data-toggle="modal" data-target="#modal-lg">
                                ADD New User
                            </button>

                        </div>
                    </div>

                    <div class="card">
                        <div class="card-body">
                            <table id="example1" class="table table-bordered table-striped"
                                style=" overflow-y:scroll;display:block;overflow-y: hidden;">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>UserName</th>
                                        <th>Email</th>
                                        <th>CurrnetRole</th>
                                        <th>RegistrationDate</th>
                                        <th>Set/Change</th>
                                        <td></td>
                                    </tr>
                                </thead>
                                <tbody>
                                    @if (count($users) > 0)
                                        @php
                                            $no = 0;
                                        @endphp
                                        @foreach ($users as $user)
                                            @php
                                                $no = $no + 1;
                                            @endphp

                                            <tr>
                                                <td>{{ $no }}</td>
                                                <td>{{ $user->name }}</td>
                                                <td>{{ $user->email }}</td>
                                                <td>
                                                    @forelse ($roles as $role)
                                                        @if ($role->id == $user->role)
                                                            <a type="button" class="text-warning"
                                                                href="#">{{ $role->role_name }}</a>
                                                        @endif
                                                    @empty
                                                    @endforelse
                                                </td>
                                                <td>{{ $user->created_at->toDateString() }}</td>
                                                <td>
                                                    <a type="button" class="btn btn-success btn-sm" data-toggle="modal"
                                                        data-target="#modal-lg-role-{{ $user->id }}">Set-Role</a>
                                                </td>
                                                <td>
                                                    <button type="button" class="btn btn-primary btn-sm"
                                                        data-toggle="modal" data-target="#modal-lg-{{ $user->id }}">
                                                        <i class="fas fa-edit"></i>

                                                    </button>
                                                    @if (auth()->user()->role == 1)
                                                        {{-- Logged in as Super Admin --}}
                                                        @if ($user->role != 1)
                                                            {{-- Show delete button only if the user is NOT Super Admin --}}
                                                            <a type="button" class="btn btn-danger btn-sm"
                                                                href="delete-user-{{ $user->id }}"
                                                                onclick="return confirm('Are you sure you want to delete this user?');">
                                                                <i class="fas fa-trash"></i>
                                                            </a>
                                                        @endif
                                                    @else
                                                        {{-- Other roles need permission to delete users --}}
                                                        @if ($permission->manage_delete_user == 'on' && $user->role != 1)
                                                            <a type="button" class="btn btn-danger btn-sm"
                                                                href="delete-user-{{ $user->id }}"
                                                                onclick="return confirm('Are you sure you want to delete this user?');">
                                                                <i class="fas fa-trash"></i>
                                                            </a>
                                                        @endif
                                                    @endif


                                                </td>
                                            </tr>

                                            <div class="modal fade" id="modal-lg-{{ $user->id }}">
                                                <div class="modal-dialog modal-lg-{{ $user->id }}">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h4 class="modal-title">Edit user</h4>
                                                            <button type="button" class="close" data-dismiss="modal"
                                                                aria-label="Close">
                                                                <span aria-hidden="true">&times;</span>
                                                            </button>
                                                        </div>
                                                        <div class="modal-body">
                                                            <div class="container-fluid">
                                                                <div class="row">
                                                                    <!-- left column -->
                                                                    <div class="col-md-12">
                                                                        <!-- jquery validation -->
                                                                        <div class="card card-primary">
                                                                            <div class="card-header">
                                                                                <h3 class="card-title">user
                                                                                    <small>Information</small>
                                                                                </h3>
                                                                            </div>
                                                                            <!-- /.card-header -->
                                                                            <!-- form start -->
                                                                            <form action="/editUser-{{ $user->id }}"
                                                                                method="POST" id="quickForm">
                                                                                @csrf
                                                                                <div class="card-body">
                                                                                    <div class="form-group">
                                                                                        <label>Full Name</label>
                                                                                        <input type="text"
                                                                                            name="full_name"
                                                                                            class="form-control"
                                                                                            value="{{ $user->name }}"
                                                                                            required>
                                                                                    </div>
                                                                                    <div class="form-group">
                                                                                        <label>Email</label>
                                                                                        <input type="email" name="email"
                                                                                            class="form-control"
                                                                                            value="{{ $user->email }}"
                                                                                            required>
                                                                                    </div>
                                                                                    <div class="form-group">
                                                                                        <label for="">Phone</label>
                                                                                        <input type="text" name="phone"
                                                                                            class="form-control"
                                                                                            value="{{ $user->phone }}"
                                                                                            pattern="[+ , 0]{1}[0 , 9]{9 , 14}">
                                                                                    </div>
                                                                                </div>

                                                                                <div
                                                                                    class="modal-footer justify-content-between">
                                                                                    <button type="button"
                                                                                        class="btn btn-default"
                                                                                        data-dismiss="modal">Close</button>
                                                                                    <button type="submit"
                                                                                        class="btn btn-primary swalDefaultSuccess"
                                                                                        onclick="return confirm('Are you sure you want to save changes ?');">Save
                                                                                        Change</button>
                                                                                </div>
                                                                            </form>
                                                                        </div>
                                                                        <!-- /.card -->
                                                                    </div>

                                                                    <!--/.col (right) -->
                                                                </div>
                                                                <!-- /.row -->
                                                            </div><!-- /.container-fluid -->

                                                        </div>
                                                    </div>
                                                    <!-- /.modal-content -->
                                                </div>
                                                <!-- /.modal-dialog -->
                                            </div>



                                            <div class="modal fade" id="modal-lg-role-{{ $user->id }}">
                                                <div class="modal-dialog modal-lg">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h4 class="modal-title">
                                                                <button type="button" class="btn btn-success"
                                                                    data-toggle="modal" data-target="#modal-lg-ADDROLE">
                                                                    <i class="fas fa-edit"></i>
                                                                    Manage Roles
                                                                </button>
                                                            </h4>
                                                            <button type="button" class="close" data-dismiss="modal"
                                                                aria-label="Close">
                                                                <span aria-hidden="true">&times;</span>
                                                            </button>
                                                        </div>
                                                        <div class="modal-body">
                                                            <div class="container-fluid">
                                                                <div class="row">
                                                                    <!-- left column -->
                                                                    <div class="col-md-12">
                                                                        <!-- jquery validation -->
                                                                        <div class="card card-primary">
                                                                            <div class="card-header">
                                                                                <h3 class="card-title"><small>set role to -
                                                                                    </small> {{ $user->name }} </h3>
                                                                            </div>

                                                                            <form action="/set-role-{{ $user->id }}"
                                                                                method="POST" id="quickForm">
                                                                                @csrf
                                                                                <div class="card-body">
                                                                                    <div class="row">
                                                                                        @forelse ($roles as $role)
                                                                                            @if ($role->supper_admin != 'on')
                                                                                                <div class="col-sm-4">
                                                                                                    <div
                                                                                                        class="form-group clearfix">
                                                                                                        <div
                                                                                                            class="icheck-success d-inline text-white">
                                                                                                            <input
                                                                                                                type="radio"
                                                                                                                id="{{ $role->id }}{{ $user->id }}"
                                                                                                                name="role"
                                                                                                                value="{{ $role->id }}"
                                                                                                                @if ($role->id == $user->role) @checked(true) @endif>

                                                                                                            <label
                                                                                                                class="text-warning"
                                                                                                                for="{{ $role->id }}{{ $user->id }}">
                                                                                                                {{ $role->role_name }}
                                                                                                            </label>
                                                                                                        </div>
                                                                                                    </div>
                                                                                                </div>
                                                                                            @endif
                                                                                        @empty
                                                                                        @endforelse
                                                                                    </div>
                                                                                </div>
                                                                                <div
                                                                                    class="modal-footer justify-content-between">
                                                                                    <button type="button"
                                                                                        class="btn btn-default"
                                                                                        data-dismiss="modal">Close</button>
                                                                                    <button type="submit"
                                                                                        class="btn btn-primary swalDefaultSuccess">Register</button>
                                                                                </div>
                                                                            </form>
                                                                        </div>
                                                                        <!-- /.card -->
                                                                    </div>

                                                                    <!--/.col (right) -->
                                                                </div>
                                                                <!-- /.row -->
                                                            </div><!-- /.container-fluid -->

                                                        </div>
                                                    </div>
                                                    <!-- /.modal-content -->
                                                </div>
                                                <!-- /.modal-dialog -->
                                            </div>
                                        @endforeach
                                    @else
                                        <h2>No user Found !</h2>
                                    @endif
                                </tbody>
                            </table>


                        </div>
                        <!-- /.card-body -->
                    </div>

                    <!-- /.card -->
                    <div class="modal fade" id="modal-lg">
                        <div class="modal-dialog modal-lg">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h4 class="modal-title">New user</h4>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <div class="modal-body">
                                    <div class="container-fluid">
                                        <div class="row">
                                            <!-- left column -->
                                            <div class="col-md-12">
                                                <!-- jquery validation -->
                                                <div class="card card-primary">
                                                    <div class="card-header">
                                                        <h3 class="card-title">User <small>Information</small></h3>
                                                    </div>
                                                    <!-- /.card-header -->
                                                    <!-- form start -->
                                                    <form action="/add-user" method="POST" id="quickForm">
                                                        @csrf
                                                        <div class="card-body">
                                                            <div class="form-group">
                                                                <label>Full Name</label>
                                                                <input type="text" name="full_name"
                                                                    class="form-control" placeholder="Full Name" required>
                                                            </div>
                                                            <div class="form-group">
                                                                <label>Email</label>
                                                                <input type="email" name="email" class="form-control"
                                                                    placeholder="Email" required>
                                                            </div>
                                                            <div class="form-group">
                                                                <label for="">Phone</label>
                                                                <input type="text" name="phone" class="form-control"
                                                                    id="" placeholder="+251"
                                                                    pattern="[+ , 0]{1}[0-9]{9,14}">
                                                            </div>
                                                        </div>

                                                        <div class="modal-footer justify-content-between">
                                                            <button type="button" class="btn btn-default"
                                                                data-dismiss="modal">Close</button>
                                                            <button type="submit"
                                                                class="btn btn-primary swalDefaultSuccess">Register</button>
                                                        </div>
                                                    </form>
                                                </div>
                                                <!-- /.card -->
                                            </div>

                                            <!--/.col (right) -->
                                        </div>
                                        <!-- /.row -->
                                    </div><!-- /.container-fluid -->

                                </div>
                            </div>
                            <!-- /.modal-content -->
                        </div>
                        <!-- /.modal-dialog -->
                    </div>
                    <!-- /.modal -->

                    <div class="modal fade" id="modal-lg-ADDROLE">
                        <div class="modal-dialog modal-lg">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h4 class="modal-title">New Role</h4>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <div class="modal-body">
                                    <div class="container-fluid">
                                        <div class="row">
                                            <!-- left column -->
                                            <div class="col-md-12">
                                                <!-- jquery validation -->
                                                <div class="card card-success">
                                                    <div class="card-header">
                                                        <h3 class="card-title">Role </h3>
                                                    </div>
                                                    <!-- /.card-header -->
                                                    <!-- form start -->
                                                    <form action="/add-role" method="POST" id="quickForm">
                                                        @csrf
                                                        <div class="card-body text-success">
                                                            <div class="form-group">
                                                                <label>Role Name</label>
                                                                <input type="text" name="role_name"
                                                                    class="form-control" placeholder="Role Name" required>
                                                            </div>

                                                            <h5>Select Permissions</h5>
                                                            <hr>

                                                            <div class="row">
                                                                <div class="col-sm-4">
                                                                    <div class="icheck-success d-inline">
                                                                        <input type="checkbox" name="manage_user"
                                                                            id="manage_user">
                                                                        <label for="manage_user">Manage User</label>
                                                                    </div>
                                                                </div>

                                                                <div class="col-sm-4">
                                                                    <div class="icheck-success d-inline">
                                                                        <input type="checkbox" name="manage_location"
                                                                            id="manage_location">
                                                                        <label for="manage_location">Manage
                                                                            Location</label>
                                                                    </div>
                                                                </div>

                                                                <div class="col-sm-4">
                                                                    <div class="icheck-success d-inline">
                                                                        <input type="checkbox" name="manage_item"
                                                                            id="manage_item">
                                                                        <label for="manage_item">Manage Item</label>
                                                                    </div>
                                                                </div>
                                                            </div>

                                                            <div class="row mt-2">
                                                                <div class="col-sm-4">
                                                                    <div class="icheck-success d-inline">
                                                                        <input type="checkbox" name="set_item_price"
                                                                            id="set_item_price">
                                                                        <label for="set_item_price">Set Item Price</label>
                                                                    </div>
                                                                </div>

                                                                <div class="col-sm-4">
                                                                    <div class="icheck-success d-inline">
                                                                        <input type="checkbox" name="manage_item_unit"
                                                                            id="manage_item_unit">
                                                                        <label for="manage_item_unit">Manage Item
                                                                            Unit</label>
                                                                    </div>
                                                                </div>

                                                                <div class="col-sm-4">
                                                                    <div class="icheck-success d-inline">
                                                                        <input type="checkbox" name="manage_category"
                                                                            id="manage_category">
                                                                        <label for="manage_category">Manage
                                                                            Category</label>
                                                                    </div>
                                                                </div>
                                                            </div>

                                                            <div class="row mt-2">
                                                                <div class="col-sm-4">
                                                                    <div class="icheck-success d-inline">
                                                                        <input type="checkbox" name="manage_delete_user"
                                                                            id="manage_delete_user">
                                                                        <label for="manage_delete_user">Manage Delete
                                                                            User</label>
                                                                    </div>
                                                                </div>

                                                                <div class="col-sm-4">
                                                                    <div class="icheck-success d-inline">
                                                                        <input type="checkbox" name="manage_delete_item"
                                                                            id="manage_delete_item">
                                                                        <label for="manage_delete_item">Manage Delete
                                                                            item</label>
                                                                    </div>
                                                                </div>

                                                                <div class="col-sm-4">
                                                                    <div class="icheck-success d-inline">
                                                                        <input type="checkbox"
                                                                            name="manage_delete_goodreceiving"
                                                                            id="manage_delete_goodreceiving">
                                                                        <label for="manage_delete_goodreceiving">Manage
                                                                            Delete GoodReceiving</label>
                                                                    </div>
                                                                </div>
                                                            </div>

                                                            <div class="row mt-2">
                                                                <div class="col-sm-4">
                                                                    <div class="icheck-success d-inline">
                                                                        <input type="checkbox" name="manage_shelf"
                                                                            id="manage_shelf">
                                                                        <label for="manage_shelf">Manage Shelf</label>
                                                                    </div>
                                                                </div>

                                                                <div class="col-sm-4">
                                                                    <div class="icheck-success d-inline">
                                                                        <input type="checkbox" name="manage_customer"
                                                                            id="manage_customer">
                                                                        <label for="manage_customer">Manage
                                                                            Customer</label>
                                                                    </div>
                                                                </div>

                                                                <div class="col-sm-4">
                                                                    <div class="icheck-success d-inline">
                                                                        <input type="checkbox"
                                                                            name="manage_good_receiving"
                                                                            id="manage_good_receiving">
                                                                        <label for="manage_good_receiving">Manage Good
                                                                            Receiving</label>
                                                                    </div>
                                                                </div>
                                                            </div>

                                                            <div class="row mt-2">
                                                                <div class="col-sm-4">
                                                                    <div class="icheck-success d-inline">
                                                                        <input type="checkbox"
                                                                            name="manage_customer_history"
                                                                            id="manage_customer_history">
                                                                        <label for="manage_customer_history">Manage
                                                                            Customer History</label>
                                                                    </div>
                                                                </div>

                                                                <div class="col-sm-4">
                                                                    <div class="icheck-success d-inline">
                                                                        <input type="checkbox" name="manage_item_transfer"
                                                                            id="manage_item_transfer">
                                                                        <label for="manage_item_transfer">Manage Item
                                                                            Transfer</label>
                                                                    </div>
                                                                </div>

                                                                <div class="col-sm-4">
                                                                    <div class="icheck-success d-inline">
                                                                        <input type="checkbox" name="manage_sales"
                                                                            id="manage_sales">
                                                                        <label for="manage_sales">Manage Sales</label>
                                                                    </div>
                                                                </div>
                                                            </div>

                                                            <div class="row mt-2">
                                                                <div class="col-sm-4">
                                                                    <div class="icheck-success d-inline">
                                                                        <input type="checkbox" name="manage_disposal"
                                                                            id="manage_disposal">
                                                                        <label for="manage_disposal">Manage
                                                                            Disposal</label>
                                                                    </div>
                                                                </div>

                                                                <div class="col-sm-4">
                                                                    <div class="icheck-success d-inline">
                                                                        <input type="checkbox" name="manage_activity_log"
                                                                            id="manage_activity_log">
                                                                        <label for="manage_activity_log">Manage Activity
                                                                            Log</label>
                                                                    </div>
                                                                </div>

                                                                <div class="col-sm-4">
                                                                    <div class="icheck-success d-inline">
                                                                        <input type="checkbox" name="approval"
                                                                            id="approval">
                                                                        <label for="approval">Approval</label>
                                                                    </div>
                                                                </div>
                                                            </div>

                                                            <div class="row mt-2">
                                                                <div class="col-sm-6">
                                                                    <div class="icheck-success d-inline">
                                                                        <input type="checkbox" name="manage_stock_reports"
                                                                            id="manage_stock_reports">
                                                                        <label for="manage_stock_reports">Manage Stock
                                                                            Reports</label>
                                                                    </div>
                                                                </div>

                                                                <div class="col-sm-6">
                                                                    <div class="icheck-success d-inline">
                                                                        <input type="checkbox"
                                                                            name="manage_shopStock_reports"
                                                                            id="manage_shopStock_reports">
                                                                        <label for="manage_shopStock_reports">Manage Shop
                                                                            Stock Reports</label>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="row mt-2">
                                                                <div class="col-sm-4">
                                                                    <div class="icheck-success d-inline">
                                                                        <input type="checkbox"
                                                                            name="manage_delete_customer"
                                                                            id="manage_delete_customer">
                                                                        <label for="manage_delete_customer">Manage Delete
                                                                            Customer</label>
                                                                    </div>
                                                                </div>

                                                                <div class="col-sm-4">
                                                                    <div class="icheck-success d-inline">
                                                                        <input type="checkbox" name="manage_delete_sales"
                                                                            id="manage_delete_sales">
                                                                        <label for="manage_delete_sales">Manage Delete
                                                                            Sales</label>
                                                                    </div>
                                                                </div>

                                                            </div>

                                                        </div>

                                                        <div class="modal-footer justify-content-between">
                                                            <button type="button" class="btn btn-default"
                                                                data-dismiss="modal">Close</button>
                                                            <button type="submit"
                                                                class="btn btn-primary swalDefaultSuccess">Register</button>
                                                        </div>
                                                    </form>

                                                </div>
                                                <!-- /.card -->
                                            </div>

                                            <!--/.col (right) -->
                                        </div>
                                        <hr>
                                        <h5>Manage Roles Here</h5>
                                        <div class="row p-2">
                                            <table class="table align-baseline"
                                                style="overflow-y:scroll;display:block;overflow-y: hidden;">
                                                <tbody class="text-info">
                                                    @forelse ($roles as $role)
                                                        @if ($role->SuperAdmin != 'on')
                                                            <form action="/edit-role-{{ $role->id }}" method="POST"
                                                                id="quickForm">
                                                                @csrf
                                                                <tr>
                                                                    <th class="text-success" scope="row">
                                                                        {{ $role->role_name }}
                                                                    </th>

                                                                    <td>
                                                                        <small>
                                                                            <div class="form-group clearfix">
                                                                                <div class="icheck-success d-inline">
                                                                                    <input type="hidden"
                                                                                        name="manage_user" value="off">
                                                                                    <input type="checkbox"
                                                                                        name="manage_user" value="on"
                                                                                        id="manage_user{{ $role->id }}"
                                                                                        @if ($role->manage_user == 'on') checked @endif>
                                                                                    <label
                                                                                        for="manage_user{{ $role->id }}">Manage
                                                                                        User</label>
                                                                                </div>

                                                                                <div class="icheck-success d-inline">
                                                                                    <input type="hidden"
                                                                                        name="manage_location"
                                                                                        value="off">
                                                                                    <input type="checkbox"
                                                                                        name="manage_location"
                                                                                        value="on"
                                                                                        id="manage_location{{ $role->id }}"
                                                                                        @if ($role->manage_location == 'on') checked @endif>
                                                                                    <label
                                                                                        for="manage_location{{ $role->id }}">Manage
                                                                                        Location</label>
                                                                                </div>
                                                                            </div>
                                                                        </small>
                                                                    </td>

                                                                    <td>
                                                                        <small>
                                                                            <div class="form-group clearfix">
                                                                                <div class="icheck-success d-inline">
                                                                                    <input type="hidden"
                                                                                        name="manage_item" value="off">
                                                                                    <input type="checkbox"
                                                                                        name="manage_item" value="on"
                                                                                        id="manage_item{{ $role->id }}"
                                                                                        @if ($role->manage_item == 'on') checked @endif>
                                                                                    <label
                                                                                        for="manage_item{{ $role->id }}">Manage
                                                                                        Item</label>
                                                                                </div>

                                                                                <div class="icheck-success d-inline">
                                                                                    <input type="hidden"
                                                                                        name="set_item_price"
                                                                                        value="off">
                                                                                    <input type="checkbox"
                                                                                        name="set_item_price"
                                                                                        value="on"
                                                                                        id="set_item_price{{ $role->id }}"
                                                                                        @if ($role->set_item_price == 'on') checked @endif>
                                                                                    <label
                                                                                        for="set_item_price{{ $role->id }}">Set
                                                                                        Item Price</label>
                                                                                </div>

                                                                                <div class="icheck-success d-inline">
                                                                                    <input type="hidden"
                                                                                        name="manage_delete_goodreceiving"
                                                                                        value="off">
                                                                                    <input type="checkbox"
                                                                                        name="manage_delete_goodreceiving"
                                                                                        value="on"
                                                                                        id="manage_delete_goodreceiving{{ $role->id }}"
                                                                                        @if ($role->manage_delete_goodreceiving == 'on') checked @endif>
                                                                                    <label
                                                                                        for="manage_delete_goodreceiving{{ $role->id }}">Manage
                                                                                        Delete GoodReceiving</label>
                                                                                </div>
                                                                            </div>
                                                                        </small>
                                                                    </td>

                                                                    <td>
                                                                        <small>
                                                                            <div class="form-group clearfix">
                                                                                <div class="icheck-success d-inline">
                                                                                    <input type="hidden"
                                                                                        name="manage_item_unit"
                                                                                        value="off">
                                                                                    <input type="checkbox"
                                                                                        name="manage_item_unit"
                                                                                        value="on"
                                                                                        id="manage_item_unit{{ $role->id }}"
                                                                                        @if ($role->manage_item_unit == 'on') checked @endif>
                                                                                    <label
                                                                                        for="manage_item_unit{{ $role->id }}">Manage
                                                                                        Item Unit</label>
                                                                                </div>

                                                                                <div class="icheck-success d-inline">
                                                                                    <input type="hidden"
                                                                                        name="manage_category"
                                                                                        value="off">
                                                                                    <input type="checkbox"
                                                                                        name="manage_category"
                                                                                        value="on"
                                                                                        id="manage_category{{ $role->id }}"
                                                                                        @if ($role->manage_category == 'on') checked @endif>
                                                                                    <label
                                                                                        for="manage_category{{ $role->id }}">Manage
                                                                                        Category</label>
                                                                                </div>

                                                                                <div class="icheck-success d-inline">
                                                                                    <input type="hidden"
                                                                                        name="manage_delete_user"
                                                                                        value="off">
                                                                                    <input type="checkbox"
                                                                                        name="manage_delete_user"
                                                                                        value="on"
                                                                                        id="manage_delete_user{{ $role->id }}"
                                                                                        @if ($role->manage_delete_user == 'on') checked @endif>
                                                                                    <label
                                                                                        for="manage_delete_user{{ $role->id }}">Manage
                                                                                        Delete User</label>
                                                                                </div>
                                                                            </div>
                                                                        </small>
                                                                    </td>

                                                                    <td>
                                                                        <small>
                                                                            <div class="form-group clearfix">
                                                                                <div class="icheck-success d-inline">
                                                                                    <input type="hidden"
                                                                                        name="manage_shelf"
                                                                                        value="off">
                                                                                    <input type="checkbox"
                                                                                        name="manage_shelf" value="on"
                                                                                        id="manage_shelf{{ $role->id }}"
                                                                                        @if ($role->manage_shelf == 'on') checked @endif>
                                                                                    <label
                                                                                        for="manage_shelf{{ $role->id }}">Manage
                                                                                        Shelf</label>
                                                                                </div>

                                                                                <div class="icheck-success d-inline">
                                                                                    <input type="hidden"
                                                                                        name="manage_customer"
                                                                                        value="off">
                                                                                    <input type="checkbox"
                                                                                        name="manage_customer"
                                                                                        value="on"
                                                                                        id="manage_customer{{ $role->id }}"
                                                                                        @if ($role->manage_customer == 'on') checked @endif>
                                                                                    <label
                                                                                        for="manage_customer{{ $role->id }}">Manage
                                                                                        Customer</label>
                                                                                </div>

                                                                                <div class="icheck-success d-inline">
                                                                                    <input type="hidden"
                                                                                        name="manage_delete_item"
                                                                                        value="off">
                                                                                    <input type="checkbox"
                                                                                        name="manage_delete_item"
                                                                                        value="on"
                                                                                        id="manage_delete_item{{ $role->id }}"
                                                                                        @if ($role->manage_delete_item == 'on') checked @endif>
                                                                                    <label
                                                                                        for="manage_delete_item{{ $role->id }}">Manage
                                                                                        Delete Item</label>
                                                                                </div>
                                                                            </div>
                                                                        </small>
                                                                    </td>

                                                                    <td>
                                                                        <small>
                                                                            <div class="form-group clearfix">
                                                                                <div class="icheck-success d-inline">
                                                                                    <input type="hidden"
                                                                                        name="manage_good_receiving"
                                                                                        value="off">
                                                                                    <input type="checkbox"
                                                                                        name="manage_good_receiving"
                                                                                        value="on"
                                                                                        id="manage_good_receiving{{ $role->id }}"
                                                                                        @if ($role->manage_good_receiving == 'on') checked @endif>
                                                                                    <label
                                                                                        for="manage_good_receiving{{ $role->id }}">Manage
                                                                                        Good Receiving</label>
                                                                                </div>

                                                                                <div class="icheck-success d-inline">
                                                                                    <input type="hidden"
                                                                                        name="manage_customer_history"
                                                                                        value="off">
                                                                                    <input type="checkbox"
                                                                                        name="manage_customer_history"
                                                                                        value="on"
                                                                                        id="manage_customer_history{{ $role->id }}"
                                                                                        @if ($role->manage_customer_history == 'on') checked @endif>
                                                                                    <label
                                                                                        for="manage_customer_history{{ $role->id }}">Manage
                                                                                        Customer History</label>
                                                                                </div>

                                                                                <div class="icheck-success d-inline">
                                                                                    <input type="hidden"
                                                                                        name="manage_delete_sales"
                                                                                        value="off">
                                                                                    <input type="checkbox"
                                                                                        name="manage_delete_sales"
                                                                                        value="on"
                                                                                        id="manage_delete_sales{{ $role->id }}"
                                                                                        @if ($role->manage_delete_sales == 'on') checked @endif>
                                                                                    <label
                                                                                        for="manage_delete_sales{{ $role->id }}">Manage
                                                                                        Delete Sales</label>
                                                                                </div>
                                                                            </div>
                                                                        </small>
                                                                    </td>

                                                                    <td>
                                                                        <small>
                                                                            <div class="form-group clearfix">
                                                                                <div class="icheck-success d-inline">
                                                                                    <input type="hidden"
                                                                                        name="manage_item_transfer"
                                                                                        value="off">
                                                                                    <input type="checkbox"
                                                                                        name="manage_item_transfer"
                                                                                        value="on"
                                                                                        id="manage_item_transfer{{ $role->id }}"
                                                                                        @if ($role->manage_item_transfer == 'on') checked @endif>
                                                                                    <label
                                                                                        for="manage_item_transfer{{ $role->id }}">Manage
                                                                                        Item Transfer</label>
                                                                                </div>

                                                                                <div class="icheck-success d-inline">
                                                                                    <input type="hidden"
                                                                                        name="manage_sales"
                                                                                        value="off">
                                                                                    <input type="checkbox"
                                                                                        name="manage_sales" value="on"
                                                                                        id="manage_sales{{ $role->id }}"
                                                                                        @if ($role->manage_sales == 'on') checked @endif>
                                                                                    <label
                                                                                        for="manage_sales{{ $role->id }}">Manage
                                                                                        Sales</label>
                                                                                </div>

                                                                                <div class="icheck-success d-inline">
                                                                                    <input type="hidden"
                                                                                        name="manage_delete_customer"
                                                                                        value="off">
                                                                                    <input type="checkbox"
                                                                                        name="manage_delete_customer"
                                                                                        value="on"
                                                                                        id="manage_delete_customer{{ $role->id }}"
                                                                                        @if ($role->manage_delete_customer == 'on') checked @endif>
                                                                                    <label
                                                                                        for="manage_delete_customer{{ $role->id }}">Manage
                                                                                        Delete Customer</label>
                                                                                </div>
                                                                            </div>
                                                                        </small>
                                                                    </td>

                                                                    <td>
                                                                        <small>
                                                                            <div class="form-group clearfix">
                                                                                <div class="icheck-success d-inline">
                                                                                    <input type="hidden"
                                                                                        name="manage_disposal"
                                                                                        value="off">
                                                                                    <input type="checkbox"
                                                                                        name="manage_disposal"
                                                                                        value="on"
                                                                                        id="manage_disposal{{ $role->id }}"
                                                                                        @if ($role->manage_disposal == 'on') checked @endif>
                                                                                    <label
                                                                                        for="manage_disposal{{ $role->id }}">Manage
                                                                                        Disposal</label>
                                                                                </div>

                                                                                <div class="icheck-success d-inline">
                                                                                    <input type="hidden"
                                                                                        name="manage_activity_log"
                                                                                        value="off">
                                                                                    <input type="checkbox"
                                                                                        name="manage_activity_log"
                                                                                        value="on"
                                                                                        id="manage_activity_log{{ $role->id }}"
                                                                                        @if ($role->manage_activity_log == 'on') checked @endif>
                                                                                    <label
                                                                                        for="manage_activity_log{{ $role->id }}">Manage
                                                                                        Activity Log</label>
                                                                                </div>
                                                                            </div>
                                                                        </small>
                                                                    </td>

                                                                    <td>
                                                                        <small>
                                                                            <div class="form-group clearfix">
                                                                                <div class="icheck-success d-inline">
                                                                                    <input type="hidden" name="approval"
                                                                                        value="off">
                                                                                    <input type="checkbox" name="approval"
                                                                                        value="on"
                                                                                        id="approval{{ $role->id }}"
                                                                                        @if ($role->approval == 'on') checked @endif>
                                                                                    <label
                                                                                        for="approval{{ $role->id }}">Approval</label>
                                                                                </div>

                                                                                <div class="icheck-success d-inline">
                                                                                    <input type="hidden"
                                                                                        name="manage_stock_reports"
                                                                                        value="off">
                                                                                    <input type="checkbox"
                                                                                        name="manage_stock_reports"
                                                                                        value="on"
                                                                                        id="manage_stock_reports{{ $role->id }}"
                                                                                        @if ($role->manage_stock_reports == 'on') checked @endif>
                                                                                    <label
                                                                                        for="manage_stock_reports{{ $role->id }}">Manage
                                                                                        Stock Reports</label>
                                                                                </div>

                                                                                <div class="icheck-success d-inline">
                                                                                    <input type="hidden"
                                                                                        name="manage_shopStock_reports"
                                                                                        value="off">
                                                                                    <input type="checkbox"
                                                                                        name="manage_shopStock_reports"
                                                                                        value="on"
                                                                                        id="manage_shopStock_reports{{ $role->id }}"
                                                                                        @if ($role->manage_shopStock_reports == 'on') checked @endif>
                                                                                    <label
                                                                                        for="manage_shopStock_reports{{ $role->id }}">Manage
                                                                                        Shop Stock Reports</label>
                                                                                </div>
                                                                            </div>
                                                                            <hr>
                                                                            <button type="submit"
                                                                                class="btn btn-warning btn-sm">
                                                                                <i class="fas fa-save"></i>
                                                                            </button>
                                                                            <a href="delete-role-{{ $role->id }}"
                                                                                class="btn btn-danger btn-sm"
                                                                                onclick="return confirm('Are you sure you want to delete this role?');">
                                                                                <i class="fas fa-trash"></i>
                                                                            </a>
                                                                        </small>
                                                                    </td>
                                                                </tr>
                                                            </form>
                                                        @endif
                                                    @empty
                                                    @endforelse
                                                </tbody>
                                            </table>
                                        </div>

                                        <!-- /.row -->
                                    </div><!-- /.container-fluid -->

                                </div>
                            </div>
                            <!-- /.modal-content -->
                        </div>
                        <!-- /.modal-dialog -->
                    </div>
                </div>
            </div>
        </div>




    </section>

@endsection
