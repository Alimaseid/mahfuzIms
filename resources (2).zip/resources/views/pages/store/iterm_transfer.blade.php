@extends('inc.frame')


@section('content')
    <section class="content">
        <div class="container-fluid">
            <div class="col-md-9">
                <div class="card card-primary card-outline">
                    <div class="card-header">
                        <div class="row">
                            <div class="col-6 lg">
                                <div class="pl-3"><b> requisitions : {{ 0 }}</b></div>
                            </div>
                            <div class="col-6 lg">
                                <button type="button" class="btn btn-primary btn-sm pull-rigth" style="float: right;"
                                    data-toggle="modal" data-target="#modal-lg">
                                    requisition
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row p-3">
                <div class="card">
                    <div class="card-body text-sm">
                        {{-- <div class="p-2" style="float: right"> {{ $salesOrders->links() }}</div> --}}
                        <table id="example1" class="table table-bordered table-striped"
                            style=" overflow-y:scroll;display:block;overflow-y: hidden;">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>RequisitionDate</th>
                                    <th>RequestFrom</th>
                                    <th>RequestBy</th>
                                    <th>RequestTo</th>
                                    <th>Status</th>
                                    <th>ItemList</th>
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody id='list'>
                                @php $no = 0 ; @endphp
                                @forelse ($requisitions as $requisition)
                                    @php $no = $no + 1 ; @endphp
                                    <tr>
                                        <td>{{ $no }}</td>
                                        <td>{{ $requisition->created_at->toDateString() }}</td>
                                        <td>{{ $requisition->requestFrom->name ?? '-' }}</td>
                                        <td>{{ $requisition->request_by }}</td>
                                        <td>{{ $requisition->requestTo->name ?? '-' }}</td>

                                        <td> <a href="">{{ $requisition->status }} </a></td>
                                        <td>
                                            <button type="button" class="btn btn-success btn-sm" data-toggle="modal"
                                                data-target="#modal-lg-view-{{ $requisition->id }}">
                                                view
                                            </button>

                                        </td>

                                        <td>
                                            @if ($requisition->status != 'Approved')
                                                <a href="/delete-requisition-{{ $requisition->id }}"
                                                    class="btn btn-danger btn-sm">
                                                    <i class="fas fa-trash "></i>
                                                </a>
                                            @endif

                                        </td>
                                    </tr>
                                    <div class="modal fade" id="modal-lg-view-{{ $requisition->id }}">
                                        <div class="modal-dialog modal-lg">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h4 class="modal-title">
                                                    </h4>
                                                    <button type="button" class="close" data-dismiss="modal"
                                                        aria-label="Close">
                                                        <span aria-hidden="true">&times;</span>
                                                    </button>
                                                </div>
                                                <div class="modal-body">
                                                    <div class="row">
                                                        <div class="col">
                                                            Item
                                                        </div>
                                                        <div class="col">
                                                            Part no1
                                                        </div>
                                                        <div class="col">
                                                            Part no2
                                                        </div>
                                                        <div class="col">
                                                            Image1
                                                        </div>
                                                        <div class="col">
                                                            Image2
                                                        </div>
                                                        <div class="col">
                                                            unit
                                                        </div>
                                                        <div class="col">
                                                            Category
                                                        </div>
                                                        <div class="col">
                                                            Shelf
                                                        </div>
                                                        <div class="col">
                                                            Batch
                                                        </div>
                                                        <div class="col">
                                                            Quantity
                                                        </div>

                                                    </div>
                                                    <hr>
                                                    @php
                                                        $total = 0;
                                                    @endphp
                                                    @forelse ($requisitionDetails as $requisitionDetail)
                                                        @if ($requisitionDetail->requisition_id == $requisition->id)
                                                            @php
                                                                $imagePath1 = str_replace(
                                                                    '\\',
                                                                    '/',
                                                                    $requisitionDetail->item->image,
                                                                );
                                                                $imagePath2 = str_replace(
                                                                    '\\',
                                                                    '/',
                                                                    $requisitionDetail->item->image2,
                                                                );
                                                            @endphp
                                                            <div class="row">
                                                                <div class="col">
                                                                    <b>{{ $requisitionDetail->item->item_name }}</b>
                                                                </div>
                                                                <div class="col">
                                                                    <b>{{ $requisitionDetail->item->product_code }}</b>
                                                                </div>
                                                                <div class="col">
                                                                    <b>{{ $requisitionDetail->item->part_number }}</b>
                                                                </div>
                                                                <div class="col">
                                                                    <img src="{{ asset($imagePath1) }}" alt=""
                                                                        style="width: 60px; height: 60px; object-fit: cover; border-radius: 5px; cursor: pointer;">

                                                                </div>
                                                                <div class="col">
                                                                    <b> <img src="{{ asset($imagePath2) }}" alt=""
                                                                            style="width: 60px; height: 60px; object-fit: cover; border-radius: 5px; cursor: pointer;">
                                                                    </b>
                                                                </div>
                                                                <div class="col">
                                                                    <b>{{ $requisitionDetail->item->unit }}</b>
                                                                </div>
                                                                <div class="col">
                                                                    <b>{{ $requisitionDetail->item->category }}</b>
                                                                </div>
                                                                <div class="col">
                                                                    <b>
                                                                        @foreach ($shelfs as $shelff)
                                                                            @if (
                                                                                $shelff->shelf->business_locations_id == $requisition->request_from &&
                                                                                    $requisitionDetail->item_id == $shelff->item_id)
                                                                                {{ $shelff->shelf->shelf_name ?? '-' }}
                                                                            @endif
                                                                        @endforeach
                                                                    </b>
                                                                </div>
                                                                <div class="col">
                                                                    <b>{{ $requisitionDetail->batch->batch_number ?? '' }}</b>
                                                                </div>
                                                                <div class="col">
                                                                    {{ number_format($requisitionDetail->quantity) }}
                                                                </div>
                                                            </div>
                                                            <br>
                                                        @endif
                                                    @empty
                                                    @endforelse

                                                </div>

                                            </div>
                                            <!-- /.modal-content -->
                                        </div>
                                        <!-- /.modal-dialog -->
                                    </div>
                                @empty
                                @endforelse
                            </tbody>
                        </table>
                        {{-- <div class="p-2" style="float: right"> {{ $salesOrders->links("pagination::bootstrap-4") }}</div> --}}
                    </div>
                    <!-- /.card-body -->
                </div>
                <!-- /.card -->
            </div>
            <div class="modal fade" id="modal-lg">
                <div class="modal-dialog modal-lg">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h4 class="modal-title">Make New requisition</h4>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <div class="container-fluid">
                                <div class="row">
                                    <!-- left column -->
                                    <div class="col-md-12">
                                        <div class="card card-default">
                                            <!-- /.card-header -->
                                            <div class="card-body">
                                                <form action="requisition" method="POST">
                                                    @csrf
                                                    <div class="card-body">
                                                        <div class="row">
                                                            <div class="col-12">
                                                                <h4>
                                                                    <i class="fas fa-globe"></i> inventory, Inc.
                                                                    <small class="float-right">Date :
                                                                        {{ \Carbon\Carbon::now()->toFormattedDateString() }}</small>
                                                                </h4>
                                                            </div>
                                                            <!-- /.col -->
                                                        </div>
                                                        <div class="row invoice-info">
                                                            <div class="col-sm-4 invoice-col">
                                                                <address>
                                                                    {{-- <strong>Company Name, Inc.</strong><br> --}}
                                                                    requisition From
                                                                    <div class="form-group">
                                                                        <select name="request_from" id="request_from"
                                                                            class="form-control" required>
                                                                            <option value="">Select Here</option>
                                                                            @foreach ($locations as $location)
                                                                                <option value="{{ $location->id }}">
                                                                                    {{ $location->name }}</option>
                                                                            @endforeach
                                                                        </select>

                                                                    </div>

                                                                </address>
                                                            </div>
                                                            <div class="col-sm-4 invoice-col">
                                                                <address>
                                                                    {{-- <strong>Company Name, Inc.</strong><br> --}}
                                                                    requisition To
                                                                    <div class="form-group">
                                                                        <select name="request_to" class="form-control"
                                                                            id="location" required>
                                                                            <option value="">Select Here</option>
                                                                            @forelse ($locations as $location)
                                                                                <option value="{{ $location->id }}">
                                                                                    {{ $location->name }}</option>
                                                                            @empty
                                                                                <option value="">Empty Location !
                                                                                </option>
                                                                            @endforelse
                                                                        </select>
                                                                    </div>

                                                                </address>
                                                            </div>

                                                            <div class="col-sm-4 invoice-col">
                                                                <address>
                                                                    {{-- <strong>Company Name, Inc.</strong><br> --}}
                                                                    requisition By
                                                                    <div class="form-group">
                                                                        <input type="text" readonly
                                                                            value="{{ Auth::user()->name }}"
                                                                            name="shipped_by" class="form-control"
                                                                            required>
                                                                    </div>

                                                            </div>
                                                            <div class="row">

                                                                <div class="col-12 table-responsive">

                                                                    <table class="table table-striped">
                                                                        <tr>
                                                                            <th>ProductNameCode</th>
                                                                            <th>Quantity</th>
                                                                            {{-- <th>CurrntBalance</th> --}}
                                                                            <th></th>
                                                                        </tr>
                                                                        <tbody id="add_items">
                                                                            <tr>
                                                                                <td style="width: 250px;">
                                                                                    <div class="dropdown w-100">
                                                                                        <input type="text"
                                                                                            placeholder="Search.."
                                                                                            id="myInput_0"
                                                                                            onclick="myFunction(0)"
                                                                                            onkeyup="filterFunction(0)"
                                                                                            class="form-control">

                                                                                        <div id="items_0"
                                                                                            class="dropdown-menu w-100"
                                                                                            style="max-height: 300px; overflow-y:auto;">
                                                                                            <ul id="item_list_0"
                                                                                                class="list-unstyled mb-0">
                                                                                            </ul>
                                                                                        </div>
                                                                                    </div>
                                                                                    <input type="hidden" id="item_id_0"
                                                                                        name="addmore[0][item_id]"
                                                                                        value="">
                                                                                    <input type="hidden" id="batch_id_0"
                                                                                        name="addmore[0][batch_id]"
                                                                                        value="">
                                                                                </td>

                                                                                <td>
                                                                                    <input type="number" min="0"
                                                                                        id='quantity_0'
                                                                                        name="addmore[0][quantity]"
                                                                                        placeholder="Quantity"
                                                                                        class="form-control input-group-sm"
                                                                                        required>
                                                                                </td>
                                                                                {{-- <td>
                                                            <input type="number" min="0" id='remain_0' readonly value="0" class="form-control input-group-sm">
                                                         </td> --}}
                                                                            </tr>
                                                                        </tbody>

                                                                    </table>
                                                                    <a href="#" id="add_new_items"
                                                                        class="btn btn-success float-right"
                                                                        style="padding:5px; text-decoration:none">

                                                                        <i class="fa fa-plus-circle"
                                                                            aria-hidden="true"></i>
                                                                    </a>

                                                                </div>
                                                                <hr><br>
                                                                <!-- /.col -->
                                                            </div>

                                                        </div>
                                                        <!-- /.card-body -->
                                                        <button type="submit"
                                                            class="btn btn-primary swalDefaultSuccess">Submit</button>
                                                </form>
                                            </div>
                                            <!-- /.card-body -->
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Image Modal -->
        <div class="modal fade" id="imageModal" tabindex="-1" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-body text-center">
                        <img id="modalImage" src="" class="img-fluid rounded">
                    </div>
                </div>
            </div>
        </div>
    </section>
    <script>
        var i = 0;
        var selectedItems = []; // ✅ keep track of selected item IDs

        // ✅ Add new item row
        $("#add_new_items").click(function() {
            ++i;
            $("#add_items").append(`
        <tr>
            <td style="width: 250px;">
                <div class="dropdown w-100 item-search" data-no="${i}">
                    <input type="text" autocomplete="off" placeholder="Search.."
                        id="myInput_${i}"
                        onclick="myFunction(${i})"
                        onkeyup="filterFunction(${i})"
                        class="form-control">

                    <div id="items_${i}" class="dropdown-menu w-100" style="max-height:250px; overflow-y:auto; display:none;">
                        <ul id="item_list_${i}" class="list-unstyled mb-0"></ul>
                    </div>
                </div>
                <input type="hidden" id="item_id_${i}" name="addmore[${i}][item_id]" value="">
                <input type="hidden" id="batch_id_${i}" name="addmore[${i}][batch_id]" value="">
            </td>
            <td>
                <input type="number" min="0" id="quantity_${i}"
                    name="addmore[${i}][quantity]"
                    placeholder="Quantity"
                    class="form-control input-group-sm" required>
            </td>
            <td>
                <button type="button" class="remove-tr"><b style="color:red">X</b></button>
            </td>
        </tr>
    `);
        });

        // ✅ Remove row
        $(document).on('click', '.remove-tr', function() {
            let row = $(this).parents('tr');
            let removedId = row.find("input[name*='item_id']").val();

            // remove from selectedItems
            selectedItems = selectedItems.filter(id => id != removedId);

            row.remove();
        });

        // ✅ Load items on click
        function myFunction(no) {
            let list = $('#item_list_' + no);

            // get selected "Requisition From" location
            let locationId = $("select[name='request_from']").val();

            if (!locationId) {
                alert("⚠️ Please select 'Requisition From' location first.");
                return;
            }

            // Always reload to avoid showing removed items
            list.html('');

            $.ajax({
                type: "POST",
                url: "{{ url('getItemForSale') }}",
                dataType: 'json',
                data: {
                    '_token': '{{ csrf_token() }}',
                    'location_id': locationId
                },
                success: function(result) {
                    $.each(result, function(index, value) {
                        // ✅ skip if already selected
                        if (selectedItems.includes(String(value.id))) return;

                        let imageUrl = value.image ? `/${value.image}` : '/images/no-image.png';
                        list.append(`
<li class="dropdown-item d-flex align-items-center" style="cursor:pointer;"
    data-name="${value.item_name.toUpperCase()} ${value.product_code.toUpperCase()}"
    onclick="selectedItem(${value.id}, ${no}, ${value.quantity}, '${value.item_name}', '${value.product_code}', '${imageUrl}', '${value.batch_id}')">
    <img src="${imageUrl}" style="width:35px;height:35px;object-fit:cover;border-radius:5px;margin-right:8px;">
    <div>
        <strong>${value.item_name}</strong><br>
        <small class="text-muted">${value.product_code} | ${value.batch_number} | Stock: ${value.quantity}</small>
    </div>
</li>
`);
                    });

                    $('#items_' + no).show(); // open dropdown
                }
            });
        }

        // ✅ Filter items
        function filterFunction(no) {
            let input = $("#myInput_" + no).val().toUpperCase();
            let found = false;

            $("#item_list_" + no + " li").each(function() {
                let text = ($(this).attr("data-name") || $(this).text()).toUpperCase();
                let match = text.indexOf(input) > -1;
                $(this).toggle(match);
                if (match) found = true;
            });

            if (found) {
                $('#items_' + no).show();
            } else {
                $('#items_' + no).hide();
            }
        }

        // ✅ Select item
        function selectedItem(id, no, quantity, name, code, imageUrl, batchId) {
            $("#items_" + no).hide();
            $("#myInput_" + no).val(name + " | " + code);
            $("#item_id_" + no).val(id);
            $("#batch_id_" + no).val(batchId);

            // ✅ add to selectedItems
            if (!selectedItems.includes(String(id))) {
                selectedItems.push(String(id));
            }

            // set max qty
            $("#quantity_" + no).attr("max", quantity);

            // remove old preview
            $("#item_image_preview_" + no).remove();

            // add preview
            $("#myInput_" + no).after(`
    <div id="item_image_preview_${no}" style="margin-top:5px;">
        <img src="${imageUrl}" style="width:50px;height:50px;border-radius:5px;cursor:pointer;" onclick="openImageModal('${imageUrl}')">
    </div>
`);
        }

        // ✅ Open image modal
        function openImageModal(src) {
            $("#modalImage").attr("src", src);
            $("#imageModal").modal("show");
        }

        // ✅ Close dropdown when clicking outside
        $(document).on("click", function(e) {
            if (!$(e.target).closest(".item-search").length) {
                $(".dropdown-menu").hide();
            }
        });
    </script>


@endsection
